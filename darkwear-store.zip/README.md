# DarkWear — Premium Streetwear T-Shirt Store

A sleek, modern dark-themed T-shirt e-commerce web application featuring pure apparel mockups (no human faces), a 3-per-row grid of 9 T-shirts, interactive full-page Product Detail views, live cart drawer, and checkout sandbox.

---

## ⚡ Quick Start: Running in VS Code ("Go Live")

1. **Open the Project in VS Code**:
   - Open VS Code.
   - Click **File > Open Folder...** and select the `darkwear` folder (`c:\Users\Admin\Desktop\darkwear`).

2. **Run with Live Server**:
   - Make sure you have the **Live Server** extension installed in VS Code (by *Ritwick Dey*).
   - In the Explorer sidebar, right-click [`index.html`](./index.html).
   - Click **"Open with Live Server"** (or click **"Go Live"** in the bottom-right status bar).
   - The store will instantly open in your default browser at `http://127.0.0.1:5500/index.html`.

---

## 👕 9 Featured T-Shirts (3 Per Row, 350–400px Each)

Every product card displays the high-resolution T-shirt garment image, product title, and price. Clicking any card opens a full **Product Detail Page** view:

| # | Name | Category | Price | Local Image |
|---|------|----------|-------|-------------|
| 1 | **Bauhaus Geometry Colorblock Tee** | Graphic | \$54.00 | `images/tshirt-geometric-bauhaus.jpg` |
| 2 | **Prime Vertical Monolith Cyan Tee** | Oversized | \$49.00 | `images/tshirt-prime-cyan.jpg` |
| 3 | **Solar Hanger Heavyweight Crewneck** | Minimal | \$46.00 | `images/tshirt-solar-hanger.jpg` |
| 4 | **Backdrop Minimalist Typographic Tee** | Minimal | \$44.00 | `images/tshirt-backdrop-white.jpg` |
| 5 | **Eat Sleep Design Repeat Dark Tee** | Graphic | \$48.00 | `images/tshirt-design-repeat.jpg` |
| 6 | **Midnight Vintage Script Navy Tee** | Graphic | \$52.00 | `images/tshirt-navy-street.jpg` |
| 7 | **Monochrome Sand Pique Street Polo** | Basic | \$52.00 | `images/tshirt-classic-polo.jpg` |
| 8 | **Studio Gallery Round Neck White Tee** | Basic | \$42.00 | `images/tshirt-white-hanger.jpg` |
| 9 | **Duo Clothesline Charcoal & Mocha Tees** | Oversized | \$58.00 | `images/tshirt-duo-hangers.jpg` |

---

## 🌟 Key Features

- **Strict Apparel Aesthetics**: 100% apparel and garment flat-lays across the hero rack, editorial banner, and catalog — **zero human faces**.
- **Responsive 3-Column Grid**: Strictly formatted with CSS Grid at `repeat(3, minmax(350px, 400px))` centered with clean gaps.
- **Dedicated Product Detail Page View**:
  - Full-size high-res product visual
  - Title, badge, and live price
  - Complete editorial product description
  - Interactive Size Selector (`S`, `M`, `L`, `XL`, `XXL`)
  - Quantity Increment/Decrement counter
  - Direct Add to Cart with flying toast feedback
  - Related items carousel
- **Interactive Cart & Drawer**: Full badge item count, subtotal calculation, quantity updates, and trash actions.
- **Checkout Sandbox**: Shipping address form and order summary with realistic order confirmation.
- **Footer with Facebook Icon**: Complete with Facebook SVG icon, Instagram, Twitter/X, and YouTube links.
- **Zero Configuration**: Pure HTML5, CSS3, and ES6 JavaScript. No compilation or npm build required for the Live Server experience.
